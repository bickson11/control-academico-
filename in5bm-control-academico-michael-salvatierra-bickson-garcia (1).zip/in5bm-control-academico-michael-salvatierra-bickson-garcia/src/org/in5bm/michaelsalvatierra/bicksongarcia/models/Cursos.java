package org.in5bm.michaelsalvatierra.bicksongarcia.models;

/**
 *
 * @author W10
 * @date Apr 11, 2022
 * @time 11:23:18 AM
 * @author Michael Steven Salvatierra Ramirez
 * Carne: 2021150
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class Cursos {
    private String id;
    private String nombreCurso;
    private String ciclo;
    private int cupoMaximo;
    private int cupoMinimo;
    private String carreraTecnicaId;
    private int horarioId;
    private int instructorId;
    private String salonId;

    public Cursos(String id, String nombreCurso, String ciclo, int cupoMaximo, int cupoMinimo, String carreraTecnicaId, int horarioId, int instructorId, String salonId) {
        this.id = id;
        this.nombreCurso = nombreCurso;
        this.ciclo = ciclo;
        this.cupoMaximo = cupoMaximo;
        this.cupoMinimo = cupoMinimo;
        this.carreraTecnicaId = carreraTecnicaId;
        this.horarioId = horarioId;
        this.instructorId = instructorId;
        this.salonId = salonId;
    }

    public Cursos() {
    }

    public Cursos(String id, String nombreCurso, String carreraTecnicaId, int horarioId, int instructorId, String salonId) {
        this.id = id;
        this.nombreCurso = nombreCurso;
        this.carreraTecnicaId = carreraTecnicaId;
        this.horarioId = horarioId;
        this.instructorId = instructorId;
        this.salonId = salonId;
    }

    
    public String getId() {
        return id;
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public String getCiclo() {
        return ciclo;
    }

    public int getCupoMaximo() {
        return cupoMaximo;
    }

    public int getCupoMinimo() {
        return cupoMinimo;
    }

    public String getCarreraTecnicaId() {
        return carreraTecnicaId;
    }

    public int getHorarioId() {
        return horarioId;
    }

    public int getInstructorId() {
        return instructorId;
    }

    public String getSalonId() {
        return salonId;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public void setCiclo(String ciclo) {
        this.ciclo = ciclo;
    }

    public void setCupoMaximo(int cupoMaximo) {
        this.cupoMaximo = cupoMaximo;
    }

    public void setCupoMinimo(int cupoMinimo) {
        this.cupoMinimo = cupoMinimo;
    }

    public void setCarreraTecnicaId(String carreraTecnicaId) {
        this.carreraTecnicaId = carreraTecnicaId;
    }

    public void setHorarioId(int horarioId) {
        this.horarioId = horarioId;
    }

    public void setInstructorId(int instructorId) {
        this.instructorId = instructorId;
    }

    public void setSalonId(String salonId) {
        this.salonId = salonId;
    }

    @Override
    public String toString() {
        return "Cursos{" + "id=" + id + ", nombreCurso=" + nombreCurso + ", ciclo=" + ciclo + ", cupoMaximo=" + cupoMaximo + ", cupoMinimo=" + cupoMinimo + ", carreraTecnicaId=" + carreraTecnicaId + ", horarioId=" + horarioId + ", instructorId=" + instructorId + ", salonId=" + salonId + '}';
    }
    
    
}
