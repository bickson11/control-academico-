package org.in5bm.michaelsalvatierra.bicksongarcia.models;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @date May 10 , 2022
 * @time 7:45:47 PM
 * @author Bill Abel Bickson Garcia Rangel
 * Carne: 2018187
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class AsignacionesAlumnos {
    Date date = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    
    private int id;
    private int alumnoId;
    private int cursoId;
    private String fechaAsignacion;

    public AsignacionesAlumnos(int id, int alumnoId, int cursoId, String fechaAsignacion) {
        this.id = id;
        this.alumnoId = alumnoId;
        this.cursoId = cursoId;
        this.fechaAsignacion = fechaAsignacion;
    }

    public AsignacionesAlumnos() {
    }

    public AsignacionesAlumnos(int id, int alumnoId, int cursoId) {
        this.id = id;
        this.alumnoId = alumnoId;
        this.cursoId = cursoId;
    }

    
    public int getId() {
        return id;
    }

    public int getAlumnoId() {
        return alumnoId;
    }

    public int getCursoId() {
        return cursoId;
    }

    public String getFechaAsignacion() {
        return fechaAsignacion;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAlumnoId(int alumnoId) {
        this.alumnoId = alumnoId;
    }

    public void setCursoId(int cursoId) {
        this.cursoId = cursoId;
    }

    public void setFechaAsignacion() {
        this.fechaAsignacion = sdf.format(date);
    }

    @Override
    public String toString() {
        return "AsignacionesAlumnos{" + "date=" + date + ", sdf=" + sdf + ", id=" + id + ", alumnoId=" + alumnoId + ", cursoId=" + cursoId + ", fechaAsignacion=" + fechaAsignacion + '}';
    }
    
    
}
