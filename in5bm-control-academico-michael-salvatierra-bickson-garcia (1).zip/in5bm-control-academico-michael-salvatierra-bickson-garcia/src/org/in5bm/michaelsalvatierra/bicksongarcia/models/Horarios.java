package org.in5bm.michaelsalvatierra.bicksongarcia.models;

/**
 *
 * @date Apr 11, 2022
 * @date Apr 19, 2022
 * @time 11:23:18 AM
 * @author Michael Steven Salvatierra Ramirez
 * Carne: 2021150
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class Horarios {
    private String id;
    private int contador;
    private byte horarioInicio;
    private byte horariofinal;
    private byte lunes;
    private byte martes;
    private byte miercoles;
    private byte jueves;
    private byte viernes;

    public Horarios() {
    }

    public Horarios(String id, int contador, byte horarioInicio) {
        this.id = id;
        this.contador = contador;
        this.horarioInicio = horarioInicio;
    }

    
    public String getId() {
        return id;
    }

    public byte getHorarioInicio() {
        return horarioInicio;
    }

    public byte getHorariofinal() {
        return horariofinal;
    }

    public byte getLunes() {
        return lunes;
    }

    public byte getMartes() {
        return martes;
    }

    public byte getMiercoles() {
        return miercoles;
    }

    public byte getJueves() {
        return jueves;
    }

    public byte getViernes() {
        return viernes;
    }

    public void setId(String id) {
        contador ++;
        id = String.valueOf(contador);
    }

    public void setHorarioInicio(byte horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public void setHorariofinal(byte horariofinal) {
        this.horariofinal = horariofinal;
    }

    public void setLunes(byte lunes) {
        this.lunes = lunes;
    }

    public void setMartes(byte martes) {
        this.martes = martes;
    }

    public void setMiercoles(byte miercoles) {
        this.miercoles = miercoles;
    }

    public void setJueves(byte jueves) {
        this.jueves = jueves;
    }

    public void setViernes(byte viernes) {
        this.viernes = viernes;
    }

    @Override
    public String toString() {
        return "Horarios{" + "id=" + id + ", contador=" + contador + ", horarioInicio=" + horarioInicio + ", horariofinal=" + horariofinal + ", lunes=" + lunes + ", martes=" + martes + ", miercoles=" + miercoles + ", jueves=" + jueves + ", viernes=" + viernes + '}';
    }
    
}
