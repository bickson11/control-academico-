package org.in5bm.michaelsalvatierra.bicksongarcia.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import org.in5bm.michaelsalvatierra.bicksongarcia.system.Principal;

/**
 *
 * @date Apr 19, 2022
 * @time 11:23:18 AM
 * @author Michael Steven Salvatierra Ramirez
 * Carne: 2021150
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */

public class AsignacionesAlumnosController implements Initializable {

    @FXML
    private Button btnCrear;
    @FXML
    private Button btnModificar;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnReporte;
    @FXML
    private Button btnCancelar;
    @FXML
    private TextField txtCarneALumno;
    @FXML
    private TextField txtIdCurso;
    @FXML
    private DatePicker dtFechaDeAsignacion;
    @FXML
    private Label lblAdvertenciaPrimerNombre1;
    @FXML
    private Label lblAdvertenciaPrimerNombre11;
    @FXML
    private TableView tblAsignacionDeAlumnos;
    @FXML
    private TableColumn colCarneAlumno;
    @FXML
    private TableColumn colFechaAsignacion;
    @FXML
    private TableColumn colIdCurso;
    @FXML
    private Button btnAtras;
    @FXML
    private Button btnGuardar;

    Principal escenarioPrincipal = new Principal();

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void clickBoton(ActionEvent event) {
        if (event.getSource().equals(btnModificar)) {
            System.out.println("Modificar");
        } else if (event.getSource().equals(btnCrear)) {
            System.out.println("Crear");
        } else if (event.getSource().equals(btnEliminar)) {
            System.out.println("Eliminar");
        } else if (event.getSource().equals(btnReporte)) {
            System.out.println("Reporte");
        } else if (event.getSource().equals(btnAtras)) {
            System.out.println("Atras");
            escenarioPrincipal.mostrarEscenaPrincipal();
        }
    }
}
