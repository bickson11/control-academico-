package org.in5bm.michaelsalvatierra.bicksongarcia.controllers;

import java.net.URL;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.in5bm.michaelsalvatierra.bicksongarcia.db.Conexion;
import org.in5bm.michaelsalvatierra.bicksongarcia.models.Alumnos;
import org.in5bm.michaelsalvatierra.bicksongarcia.models.Salones;
import org.in5bm.michaelsalvatierra.bicksongarcia.system.Principal;

/**
 *
 * @date May 12, 2022
 * @time 10:30:13 AM
 * @author Bill Abel Bickson Garcia Rangel
 * Carne: 2018187
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class SalonesController implements Initializable {

    private enum Operacion{
        NINGUNO, GUARDAR, ACTUALIZAR
    }
    
    private Operacion operacion = Operacion.NINGUNO;
    
    @FXML
    private Button btnModificar;
    
    @FXML
    private Button btnCrear;
    
    @FXML
    private Button btnEliminar;
    
    @FXML
    private Button btnReporte;
    
    @FXML
    private TextField txtDescripcion;
    
    @FXML
    private TextField txtEdificio;
    
    @FXML
    private Spinner<?> spCapacidadMaxima;
    
    @FXML
    private Spinner<?> spNivel;
    
    @FXML
    private Label lblAdvertenciaPrimerNombre;
    
    @FXML
    private TextField txtCodigoDelSalon;
    
    @FXML
    private TableView tblSalones;
    
    @FXML
    private TableColumn colCodigoSalon;
    
    @FXML
    private TableColumn colDescripcion;
    
    @FXML
    private TableColumn colCapacidadMax;
    
    @FXML
    private TableColumn colEdificio;
    
    @FXML
    private TableColumn colNivel;
    
    @FXML
    private Button btnAtras;
    
    @FXML
    private ImageView imgCrear;    
    
    @FXML
    private ImageView imgModificar;
    
    @FXML
    private ImageView imgEliminar;
    
    Principal escenarioPrincipal = new Principal();
    private int clickBtnModificar;

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    private final String PAQUETE_IMAGES = "org/in5bm/michaelsalvatierra/bicksongarcia/resources/images/";
    private ObservableList<Salones> listaSalones; 
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarSalones();
    }    
    

    @FXML
    private void clickCrear(ActionEvent event) {
        switch (operacion) {
            case NINGUNO:
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                limpiarCampos();
                habilitarCampos();
                imgCrear.setFitHeight(80);
                imgCrear.setFitWidth(120);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "button save.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "BTN-CANCELAR.png"));
                operacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                //guardarAction();
                imgCrear.setFitHeight(70);
                imgCrear.setFitWidth(100);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                operacion = Operacion.NINGUNO;
                break;
        }
    }

    @FXML
    private void clickEliminar(ActionEvent event) {
         switch(operacion){
            case ACTUALIZAR: //CANCELAR DE ACTUALIZACION
                limpiarCampos();
                deshabilitarCampos();
                btnCrear.setDisable(false);
                btnReporte.setDisable(false);
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                imgEliminar.setImage(new Image(PAQUETE_IMAGES + "button-eliminar.png"));
                operacion = Operacion.NINGUNO;
                break;
            case NINGUNO:
                deshabilitarCampos();
                //eliminar();
                break;
        }
    }

    @FXML
    private void clickModificar(ActionEvent event) {
        switch(operacion){
            case NINGUNO:
                btnCrear.setDisable(true);
                btnReporte.setDisable(true);
                habilitarCampos();
                limpiarCampos();
                imgModificar.setFitHeight(80);
                imgModificar.setFitWidth(120);
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button save.png"));
                imgEliminar.setImage(new Image(PAQUETE_IMAGES + "BTN-CANCELAR.png"));
                clickBtnModificar = 1;
                //editar();
                operacion=Operacion.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                //guardarAction();
                operacion = Operacion.NINGUNO;
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                btnCrear.setDisable(false);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                break;
            case GUARDAR: //CANCELAR EN CREAR
                imgCrear.setFitHeight(70);
                imgCrear.setFitWidth(100);
                deshabilitarCampos();
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                operacion = Operacion.NINGUNO;
                break;
        }
    }

    @FXML
    private void clickRegresar(ActionEvent event) {
        System.out.println("Atras");
        escenarioPrincipal.mostrarEscenaPrincipal();   
    }

    @FXML
    private void clickReporte(ActionEvent event) {
        System.out.println("Reporte");
        reporte();
    }
    
    private void habilitarCampos(){
        txtCodigoDelSalon.setEditable(true);
        txtDescripcion.setEditable(true);
        txtEdificio.setEditable(true);
       
        txtCodigoDelSalon.setDisable(false);
        txtDescripcion.setDisable(false);
        spCapacidadMaxima.setDisable(false);
        txtEdificio.setDisable(false);
        spNivel.setDisable(false);
    }
    
    private void deshabilitarCampos(){
        txtCodigoDelSalon.setDisable(true);
        txtDescripcion.setDisable(true);
        spCapacidadMaxima.setDisable(true);
        txtEdificio.setDisable(true);
        spNivel.setDisable(true);
    }

    private void limpiarCampos(){
        txtCodigoDelSalon.setText("");
        txtDescripcion.setText("");
        txtEdificio.setText("");
    }
    
    private void reporte(){
            Alert reporte = new Alert(Alert.AlertType.INFORMATION);
            reporte.setTitle("Control Academico KINAL");
            Stage stageReporte = (Stage)reporte.getDialogPane().getScene().getWindow();
            stageReporte.getIcons().add(new Image(PAQUETE_IMAGES+"ICONO.png"));
            reporte.setHeaderText(null);
            reporte.setContentText("Lo lamento, Esta función es solo para subscriptores premium :( .");
            reporte.showAndWait();
    }
    
    private ObservableList getSalones(){
        List <Salones> lista= new ArrayList<>();
        CallableStatement sentencia = null;
        ResultSet rs = null;
        try {
            String SQL = "CALL sp_salones_read();";
            sentencia = Conexion.getInstance().getConnection().prepareCall(SQL);
            rs = sentencia.executeQuery();
            while(rs.next() == true){
                Salones salon = new Salones();
                salon.setCodigoSalon(rs.getString(1));
                salon.setDescripcion(rs.getString(2));
                salon.setCapacidadMaxima(Integer.parseInt(rs.getString(3)));
                salon.setEdificio(rs.getString(4));
                salon.setNivel(Integer.parseInt(rs.getString(5)));
                lista.add(salon);
                System.out.println(salon.toString());
            }
            listaSalones = FXCollections.observableArrayList(lista);
        } catch (SQLException e) {
            System.err.println("\nSe Produjo u error al intentar consultarla lista de Salones");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Ocurrio un error al listar "+e.getMessage());
            System.err.println("Track del error ");
            e.printStackTrace();
        }finally{
            try{
                if(rs != null){
                    rs.close();
                }
                if(sentencia != null){
                    sentencia.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return listaSalones;
    }
    
     private void cargarSalones(){
        tblSalones.setItems(getSalones());
        colCodigoSalon.setCellValueFactory(new PropertyValueFactory<Salones, String>("codigoSalon"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<Salones, String>("descripcion"));
        colCapacidadMax.setCellValueFactory(new PropertyValueFactory<Salones, String>("capacidadMaxima"));
        colEdificio.setCellValueFactory(new PropertyValueFactory<Salones, String>("edificio"));
        colNivel.setCellValueFactory(new PropertyValueFactory<Salones, String>("nivel"));
    }
}
