package org.in5bm.michaelsalvatierra.bicksongarcia.controllers;

import java.net.URL;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.in5bm.michaelsalvatierra.bicksongarcia.db.Conexion;
import org.in5bm.michaelsalvatierra.bicksongarcia.models.CarrerasTecnicas;
import org.in5bm.michaelsalvatierra.bicksongarcia.system.Principal;

/**
 *
 * @date Apr 19, 2022
 * @time 9:35:47 AM
 * @author Bill Abel Bickson Garcia Rangel
 * Carne: 2018187
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class CarrerasTecnicasController implements Initializable {
    
    private enum Operacion {
        NINGUNO, GUARDAR, ACTUALIZAR
    }
    
    private Operacion operacion = Operacion.NINGUNO;
        
    @FXML
    private Button btnModificar;
    
    @FXML
    private Button btnCrear;
    
    @FXML
    private Button btnEliminar;
    
    @FXML
    private Button btnReporte;
    
    @FXML
    private Label lblAdvertenciaCarrera;
    
    @FXML
    private ComboBox<?> cbCarrera;
    
    @FXML
    private ComboBox<?> cbGrado;
    
    @FXML
    private Label lblAdvertenciaGrado;
    
    @FXML
    private Label lblAdvertenciaSeccion;
    
    @FXML
    private RadioButton rbA;
    
    @FXML
    private RadioButton rbB;
    
    @FXML
    private RadioButton rbC;
    
    @FXML
    private RadioButton rbD;
    
    @FXML
    private RadioButton rbE;
    
    @FXML
    private ComboBox<?> cbJornada;
    
    @FXML
    private Label lblAdvertenciaJornada;
    
    @FXML
    private Label lblCodigoTecnico;
    
    @FXML
    private Label lblAdvertenciaCodigoTecnico;
    
    @FXML
    private TableView tblCarrerasTecnicas;
    
     @FXML
    private TableColumn colCodigoTecnico;
     
    @FXML
    private TableColumn colCarrera;
    
    @FXML
    private TableColumn colGrado;
    
    @FXML
    private TableColumn colSeccion;
    
    @FXML
    private TableColumn colJornada;
    
    @FXML
    private Button btnAtras;
    
    @FXML
    private ImageView imgCrear;    
    
    @FXML
    private ImageView imgModificar;
    
    @FXML
    private ImageView imgEliminar;
    
    private Principal escenarioPrincipal;
    private int clickBtnModificar;

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    private final String PAQUETE_IMAGES = "org/in5bm/michaelsalvatierra/bicksongarcia/resources/images/";
    private ObservableList <CarrerasTecnicas> listaCarrerasTecnicas;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarCarrerasTecnicas();
    }    

    

    @FXML
    private void clickCrear(ActionEvent event) {
        switch(operacion){
            case NINGUNO:
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                limpiarCampos();
                habilitarCampos();
                imgCrear.setFitHeight(80);
                imgCrear.setFitWidth(120);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "button save.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "BTN-CANCELAR.png"));
                operacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                //guardarAction();
                imgCrear.setFitHeight(70);
                imgCrear.setFitWidth(100);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                operacion = Operacion.NINGUNO;
                break;
        }
    }

    @FXML
    private void clickEliminar(ActionEvent event) {
        switch(operacion){
            case ACTUALIZAR: //CANCELAR DE ACTUALIZACION
                limpiarCampos();
                deshabilitarCampos();
                btnCrear.setDisable(false);
                btnReporte.setDisable(false);
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                imgEliminar.setImage(new Image(PAQUETE_IMAGES + "button-eliminar.png"));
                operacion = Operacion.NINGUNO;
                break;
            case NINGUNO:
                deshabilitarCampos();
                //eliminar();
                break;
        }
    }

    @FXML
    private void clickModificar(ActionEvent event) {
        switch(operacion){
            case NINGUNO:
                btnCrear.setDisable(true);
                btnReporte.setDisable(true);
                habilitarCampos();
                limpiarCampos();
                imgModificar.setFitHeight(80);
                imgModificar.setFitWidth(120);
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button save.png"));
                imgEliminar.setImage(new Image(PAQUETE_IMAGES + "BTN-CANCELAR.png"));
                clickBtnModificar = 1;
                //editar();
                operacion=Operacion.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                //guardarAction();
                operacion = Operacion.NINGUNO;
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                btnCrear.setDisable(false);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                break;
            case GUARDAR: //CANCELA EN CREAR
                imgCrear.setFitHeight(70);
                imgCrear.setFitWidth(100);
                deshabilitarCampos();
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                operacion = Operacion.NINGUNO;
                break;
        }
    }

    @FXML
    private void clickRegresar(ActionEvent event) {
        System.out.println("Atras");
        escenarioPrincipal.mostrarEscenaPrincipal();   
    }

    @FXML
    private void clickReporte(ActionEvent event) {
        System.out.println("Reporte");
        reporte();
    }
    
    private void habilitarCampos(){     
        cbCarrera.setDisable(false);
        cbGrado.setDisable(false);
        cbJornada.setDisable(false);
        lblCodigoTecnico.setDisable(false);
        rbA.setDisable(false);
        rbB.setDisable(false);
        rbC.setDisable(false);
        rbD.setDisable(false);
        rbE.setDisable(false);
    }
    
    private void deshabilitarCampos(){
        cbCarrera.setDisable(true);
        cbGrado.setDisable(true);
        cbJornada.setDisable(true);
        lblCodigoTecnico.setDisable(true);
        rbA.setDisable(true);
        rbB.setDisable(true);
        rbC.setDisable(true);
        rbD.setDisable(true);
        rbE.setDisable(true);
    }

    private void limpiarCampos(){
//        txtNombre1.setText("");
//        txtNombre2.setText("");
//        txtNombre3.setText("");
//        txtApellido1.setText("");
//        txtApellido2.setText("");
    }
    
    private void reporte() {
        Alert reporte = new Alert(Alert.AlertType.INFORMATION);
        reporte.setTitle("Control Academico KINAL");
        Stage stageReporte = (Stage) reporte.getDialogPane().getScene().getWindow();
        stageReporte.getIcons().add(new Image(PAQUETE_IMAGES + "ICONO.png"));
        reporte.setHeaderText(null);
        reporte.setContentText("Lo lamento, Esta función es solo para subscriptores premium :( .");
        reporte.showAndWait();
    }
    
    private ObservableList getCarrerasTecnicas(){
        List <CarrerasTecnicas> lista= new ArrayList<>();
        CallableStatement sentencia = null;
        ResultSet rs = null;
        try {
            String SQL = "CALL sp_carreras_tecnicas_read();";
            sentencia = Conexion.getInstance().getConnection().prepareCall(SQL);
            rs = sentencia.executeQuery();
            while(rs.next() == true){
                CarrerasTecnicas carreraTecnica = new CarrerasTecnicas();
                carreraTecnica.setCodigoTecnico(rs.getString(1));
                carreraTecnica.setCarrera(rs.getString(2));
                carreraTecnica.setGrado(rs.getString(3));
                carreraTecnica.setSeccion(rs.getString(4));
                carreraTecnica.setJornada(rs.getString(5));
                lista.add(carreraTecnica);
                System.out.println(carreraTecnica.toString());
                listaCarrerasTecnicas = FXCollections.observableArrayList(lista);
            }

        } catch (SQLException e) {
            System.err.println("\nSe Produjo u error al intentar consultarla lista de Carreras Tecnicas");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Ocurrio un error al listar "+e.getMessage());
            System.err.println("Track del error ");
            e.printStackTrace();
        }finally{
            try{
                if(rs != null){
                    rs.close();
                }
                if(sentencia != null){
                    sentencia.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return listaCarrerasTecnicas;
    }
    
        private void cargarCarrerasTecnicas(){
        tblCarrerasTecnicas.setItems(getCarrerasTecnicas());
        colCodigoTecnico.setCellValueFactory(new PropertyValueFactory<CarrerasTecnicas, String>("codigoTecnico"));
        colCarrera.setCellValueFactory(new PropertyValueFactory<CarrerasTecnicas, String>("carrera"));
        colGrado.setCellValueFactory(new PropertyValueFactory<CarrerasTecnicas, String>("grado"));
        colSeccion.setCellValueFactory(new PropertyValueFactory<CarrerasTecnicas, String>("seccion"));
        colJornada.setCellValueFactory(new PropertyValueFactory<CarrerasTecnicas, String>("jornada"));
    }
}
