package org.in5bm.michaelsalvatierra.bicksongarcia.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import org.in5bm.michaelsalvatierra.bicksongarcia.system.Principal;

/**
 * @date May 9, 2022
 * @time 10:23:53 PM
 * @author Bill Abel Bickson Garcia Rangel
 * Carne: 2018187
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class HorariosController implements Initializable {

    @FXML
    private Button btnModificar;
    @FXML
    private Button btnCrear;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnReporte;
    @FXML
    private Button btnGuardar;
    @FXML
    private Label lblAdvertenciaPrimerNombre1;
    @FXML
    private Label lblAdvertenciaPrimerNombre11;
    @FXML
    private TableView<?> tblHorarios;
    @FXML
    private CheckBox cbLunes;
    @FXML
    private CheckBox cbMartes;
    @FXML
    private CheckBox cbMiercoles;
    @FXML
    private CheckBox cbJueves;
    @FXML
    private CheckBox cbViernes;
    @FXML
    private Button btnAtras;
    @FXML
    private Button btnCancelar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
        private Principal escenarioPrincipal;

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
        
   @FXML
    private void clickBoton(ActionEvent event) {
        if (event.getSource().equals(btnModificar)) {
            //editar();
        } else if (event.getSource().equals(btnCrear)) {
            //limpiarCampos();
            btnGuardar.setVisible(true);
            //alumno.setCarne();
            //lblCarne.setText(alumno.getCarne());
            //habilitarCampos();
            btnCancelar.setVisible(true);
            //validaciones(true);
        } else if (event.getSource().equals(btnEliminar)) {
           // deshabilitarCampos();
            //eliminar();
        } else if (event.getSource().equals(btnReporte)) {
            System.out.println("Reporte");
            //reporte();
        } else if (event.getSource().equals(btnAtras)) {
            System.out.println("Atras");
             escenarioPrincipal.mostrarEscenaPrincipal();
        } else if (event.getSource().equals(btnGuardar)) {
            //guardarAction();
            btnGuardar.setVisible(false);
            btnCancelar.setVisible(false);
        }else if (event.getSource().equals(btnCancelar)) {
            btnGuardar.setVisible(false);
            btnCancelar.setVisible(false);
            //alumnoSelect = null;
            //deshabilitarCampos();
            //limpiarCampos();
        }
    }
    
}
