package org.in5bm.michaelsalvatierra.bicksongarcia.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import org.in5bm.michaelsalvatierra.bicksongarcia.system.Principal;

/**
 *
 * @date May 6, 2022
 * @time 8:10:24 PM
 * @author Bill Abel Bickson Garcia Rangel
 * Carne: 2018187
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class InstructoresController implements Initializable{ 
    
    @FXML
    private Button btnModificar;

    @FXML
    private Button btnCrear;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button btnReporte;

    @FXML
    private Button btnAtras;
    
    @FXML
    private Button btnCancelar;

    @FXML
    private TextField txtPrimerNombre;

    @FXML
    private TextField txtSegundoNombre;

    @FXML
    private TextField txtTercerNombre;

    @FXML
    private TextField txtPrimerApellido;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField tctDireccion;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtTelefono;

    @FXML
    private DatePicker dateFechaDeNacimiento;

    @FXML
    private Label lblID;

    @FXML
    private TableView tblInstructores;
    
    @FXML
    private TableColumn colId;

    @FXML
    private TableColumn colNombre1;

    @FXML
    private TableColumn colNombre2;

    @FXML
    private TableColumn colNombre3;

    @FXML
    private TableColumn colApellido1;

    @FXML
    private TableColumn colApellido2;

    @FXML
    private TableColumn colTelefono;

    @FXML
    private TableColumn colEmail;

    @FXML
    private TableColumn colFechaNacimiento;
    
    @FXML
    private Button btnGuardar;
    
    private Principal escenarioPrincipal;

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
        
   @FXML
    private void clickBoton(ActionEvent event) {
        if (event.getSource().equals(btnModificar)) {
            //editar();
        } else if (event.getSource().equals(btnCrear)) {
            //limpiarCampos();
            btnGuardar.setVisible(true);
            //alumno.setCarne();
            //lblCarne.setText(alumno.getCarne());
            //habilitarCampos();
            btnCancelar.setVisible(true);
            //validaciones(true);
        } else if (event.getSource().equals(btnEliminar)) {
           // deshabilitarCampos();
            //eliminar();
        } else if (event.getSource().equals(btnReporte)) {
            System.out.println("Reporte");
            //reporte();
        } else if (event.getSource().equals(btnAtras)) {
            System.out.println("Atras");
             escenarioPrincipal.mostrarEscenaPrincipal();
        } else if (event.getSource().equals(btnGuardar)) {
            //guardarAction();
            btnGuardar.setVisible(false);
            btnCancelar.setVisible(false);
        }else if (event.getSource().equals(btnCancelar)) {
            btnGuardar.setVisible(false);
            btnCancelar.setVisible(false);
            //alumnoSelect = null;
            //deshabilitarCampos();
            //limpiarCampos();
        }
    }
    
        @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
}
