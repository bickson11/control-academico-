package org.in5bm.michaelsalvatierra.bicksongarcia.controllers;

import java.sql.ResultSet;
import java.sql.CallableStatement;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.in5bm.michaelsalvatierra.bicksongarcia.models.Alumnos;
import java.text.SimpleDateFormat;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.in5bm.michaelsalvatierra.bicksongarcia.db.Conexion;
import org.in5bm.michaelsalvatierra.bicksongarcia.system.Principal;
import java.util.ArrayList;
import java.util.Date;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
/**
 *
 * @date Apr 19, 2022
 * @time 7:35:47 AM
 * @author Michael Steven Salvatierra Ramirez
 * Carne: 2021150
 * Grado: 5to perito en Informatica 
 * Seccion y grupo: IN5BM Grupo 2 (Lunes)
 * Catedratico: Lic. Jorge Luis Perez Canto
 */
public class AlumnosController implements Initializable{

    private enum Operacion{
    NINGUNO, GUARDAR, ACTUALIZAR
    }
    
    private Operacion operacion = Operacion.NINGUNO;

    @FXML
    private Button btnCrear;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button btnReporte;

    @FXML
    private TextField txtNombre1;

    @FXML
    private TextField txtNombre2;

    @FXML
    private TextField txtNombre3;

    @FXML
    private TextField txtApellido1;

    @FXML
    private TextField txtApellido2;

    @FXML
    private Label lblCarne;
    @FXML
    private TableView tblAlumnos;
    
    @FXML
    private TableColumn colCarne;

    @FXML
    private TableColumn colNombre1;

    @FXML
    private TableColumn colNombre2;

    @FXML
    private TableColumn colNombre3;

    @FXML
    private TableColumn colApellido1;

    @FXML
    private TableColumn colApellido2;

    @FXML
    private Button btnAtras;

    @FXML
    private Label lblAdvertenciaPrimerNombre;

    @FXML
    private Label lblAdvertenciaPrimerApellido;
    
    @FXML
    private Button btnGuardar;
    
    @FXML
    private ImageView imgCrear;    
    
    @FXML
    private ImageView imgModificar;
    
    @FXML
    private ImageView imgEliminar;
    
    private Alumnos alumnoSelect;
    private final String PAQUETE_IMAGES = "org/in5bm/michaelsalvatierra/bicksongarcia/resources/images/";
    private Principal escenarioPrincipal;
    private ObservableList<Alumnos> listaAlumnos;
    private String carne;
    private static int contador;
    private int clickBtnModificar;
    Date date = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
    
    Alumnos alumno = new Alumnos();
    
    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    

    @FXML
    private void clickCrear(ActionEvent event) {
        switch(operacion){
            case NINGUNO:
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                limpiarCampos();
                setCarne();
                lblCarne.setText(alumno.getCarne());
                habilitarCampos();
                imgCrear.setFitHeight(80);
                imgCrear.setFitWidth(120);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "button save.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "BTN-CANCELAR.png"));
                operacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                guardarAction();
                imgCrear.setFitHeight(70);
                imgCrear.setFitWidth(100);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                operacion = Operacion.NINGUNO;
                break;
        }
    }

    @FXML
    private void clickEliminar(ActionEvent event) {
        switch(operacion){
            case ACTUALIZAR: //CANCELAR DE ACTUALIZACION
                limpiarCampos();
                deshabilitarCampos();
                btnCrear.setDisable(false);
                btnReporte.setDisable(false);
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                imgEliminar.setImage(new Image(PAQUETE_IMAGES + "button-eliminar.png"));
                operacion = Operacion.NINGUNO;
                break;
            case NINGUNO:
                deshabilitarCampos();
                eliminar();
                break;
        }
    }

    @FXML
    private void clickModificar(ActionEvent event) {
        switch(operacion){
            case NINGUNO:
                btnCrear.setDisable(true);
                btnReporte.setDisable(true);
                limpiarCampos();
                imgModificar.setFitHeight(80);
                imgModificar.setFitWidth(120);
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button save.png"));
                imgEliminar.setImage(new Image(PAQUETE_IMAGES + "BTN-CANCELAR.png"));
                clickBtnModificar = 1;
                editar();
                operacion=Operacion.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                guardarAction();
                operacion = Operacion.NINGUNO;
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                btnCrear.setDisable(false);
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                break;
            case GUARDAR: //CANCELAR DE CREAR
                imgCrear.setFitHeight(70);
                imgCrear.setFitWidth(100);
                deshabilitarCampos();
                contador = contador -1;
                imgCrear.setImage(new Image(PAQUETE_IMAGES + "crear-removebg-preview.png"));
                imgModificar.setImage(new Image(PAQUETE_IMAGES + "button-modificar.png"));
                btnEliminar.setDisable(false);
                btnReporte.setDisable(false);
                operacion = Operacion.NINGUNO;
                break;
        }
    }

    @FXML
    private void clickRegresar(ActionEvent event) {
        System.out.println("Atras");
        escenarioPrincipal.mostrarEscenaPrincipal();   
    }

    @FXML
    private void clickReporte(ActionEvent event) {
        System.out.println("Reporte");
        reporte();
    }
    
    public String setCarne() {
        contador++;
        if (contador < 9) {
            String year = sdf.format(date);
            carne = year + "00" + contador;
        }else if ((contador > 9) && (contador < 100)) {
            String year = sdf.format(date);
            carne = year + "0" + contador;
        }else if ((contador > 100) && (contador < 200)) {
            String year = sdf.format(date);
            carne = year + "" + contador;
        }
        alumno.setCarne(carne);
        return carne;
    }
    
    private boolean registrar(Alumnos alumno){
        System.out.println("\n Se guardo el alumno:  "+alumno);
        CallableStatement sentencia = null;
        try{
            String SQL ="CALL sp_alumnos_create(?,?,?,?,?,?);";
            sentencia = Conexion.getInstance().getConnection().prepareCall(SQL);
            
            sentencia.setString(1,alumno.getCarne());
            sentencia.setString(2,alumno.getNombre1());
            sentencia.setString(3,alumno.getNombre2());
            sentencia.setString(4,alumno.getNombre3());
            sentencia.setString(5,alumno.getApellido1());
            sentencia.setString(6,alumno.getApellido2());
            
            sentencia.executeUpdate();
            sentencia.close();
            return true;
        }catch(Exception e){
            System.err.println("Ocurrio un error al registrar la tarea "+e.getMessage());
            System.err.println("Track del error ");
            e.printStackTrace();
            return false;
        }finally{
            try{
                if(sentencia != null){
                    sentencia.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }

    }
            
    private void guardarAction(){
        boolean rsp;
        switch(operacion){
            case GUARDAR:
                alumno.setNombre1(txtNombre1.getText());
                alumno.setNombre2(txtNombre2.getText());
                alumno.setNombre3(txtNombre3.getText());
                alumno.setApellido1(txtApellido1.getText());
                alumno.setApellido2(txtApellido2.getText());

                rsp = registrar(alumno);

                    if(rsp){
                        limpiarCampos();
                        //setCarne();
                        deshabilitarCampos();    
                        cargarAlumnos();
                        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
                        alerta.setTitle("Exito");
                        alerta.setHeaderText(null);
                        alerta.setContentText("El registro se ha llevado con exito");
                        alerta.initStyle(StageStyle.UTILITY);
                        alerta.showAndWait();
                    }else{
                        Alert alerta = new Alert(Alert.AlertType.ERROR);
                        alerta.setTitle("Error");
                        alerta.setHeaderText(null);
                        alerta.setContentText("Hubo un error, consulte con el programador");
                        alerta.initStyle(StageStyle.UTILITY);
                        alerta.showAndWait();
                        }
                break;
            case ACTUALIZAR:
                alumnoSelect.setCarne(lblCarne.getText());
                alumnoSelect.setNombre1(txtNombre1.getText());
                alumnoSelect.setNombre2(txtNombre2.getText());
                alumnoSelect.setNombre3(txtNombre3.getText());
                alumnoSelect.setApellido1(txtApellido1.getText());
                alumnoSelect.setApellido2(txtApellido2.getText());

                System.out.println("\nAlumno Editado : "+alumnoSelect);
                rsp = editarStatement(alumnoSelect);

                if (rsp) {
                    limpiarCampos();
                    deshabilitarCampos();
                    cargarAlumnos();
                    Alert alerta = new Alert(Alert.AlertType.INFORMATION);
                    alerta.setTitle("Exito");
                    alerta.setHeaderText(null);
                    alerta.setContentText("La modificacion se ha llevado con exito");
                    alerta.initStyle(StageStyle.UTILITY);
                    alumnoSelect = null;
                    alerta.showAndWait();
                } else {
                    Alert alerta = new Alert(Alert.AlertType.ERROR);
                    alerta.setTitle("Error");
                    alerta.setHeaderText(null);
                    alerta.setContentText("Hubo un error, consulte con el programador");
                    alerta.initStyle(StageStyle.UTILITY);
                    alerta.showAndWait();
                }
                break;
            }
        }
    
    private void reporte(){
            Alert reporte = new Alert(Alert.AlertType.INFORMATION);
            reporte.setTitle("Control Academico KINAL");
            Stage stageReporte = (Stage)reporte.getDialogPane().getScene().getWindow();
            stageReporte.getIcons().add(new Image(PAQUETE_IMAGES+"ICONO.png"));
            reporte.setHeaderText(null);
            reporte.setContentText("Lo lamento, Esta función es solo para subscriptores premium :( .");
            reporte.showAndWait();
    }
    
    private void habilitarCampos(){
        txtNombre1.setEditable(true);
        txtNombre2.setEditable(true);
        txtNombre3.setEditable(true);
        txtApellido1.setEditable(true);
        txtApellido2.setEditable(true);
        
        txtNombre1.setDisable(false);
        txtNombre2.setDisable(false);
        txtNombre3.setDisable(false);
        txtApellido1.setDisable(false);
        txtApellido2.setDisable(false);
    }
    
    private void deshabilitarCampos(){
        lblCarne.setText("");
        txtNombre1.setEditable(false);
        txtNombre2.setEditable(false);
        txtNombre3.setEditable(false);
        txtApellido1.setEditable(false);
        txtApellido2.setEditable(false);
        
        txtNombre1.setDisable(true);
        txtNombre2.setDisable(true);
        txtNombre3.setDisable(true);
        txtApellido1.setDisable(true);
        txtApellido2.setDisable(true);
    }

    private void limpiarCampos(){
        txtNombre1.setText("");
        txtNombre2.setText("");
        txtNombre3.setText("");
        txtApellido1.setText("");
        txtApellido2.setText("");
    }
    
     private ObservableList getAlumnos(){
        List <Alumnos> lista= new ArrayList<>();
        CallableStatement sentencia = null;
        ResultSet rs = null;
        try {
            String SQL = "CALL sp_alumnos_read();";
            
            sentencia = Conexion.getInstance().getConnection().prepareCall(SQL);
            rs = sentencia.executeQuery();
            System.out.println("");
            while(rs.next() == true){
                Alumnos alumno = new Alumnos();
                alumno.setCarne(rs.getString(1));
                alumno.setNombre1(rs.getString(2));
                alumno.setNombre2(rs.getString(3));
                alumno.setNombre3(rs.getString(4));
                alumno.setApellido1(rs.getString(5));
                alumno.setApellido2(rs.getString(6));
                lista.add(alumno);
                System.out.println(alumno.toString());
            }
            System.out.println("");
            listaAlumnos = FXCollections.observableArrayList(lista);
            
        } catch (SQLException e) {
            System.err.println("\nSe Produjo u error al intentar consultarla lista de Alumnos");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Ocurrio un error al listar "+e.getMessage());
            System.err.println("Track del error ");
            e.printStackTrace();
        }finally{
            try{
                if(rs != null){
                    rs.close();
                }
                if(sentencia != null){
                    sentencia.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return listaAlumnos;
    }
    
    private void cargarAlumnos(){
        tblAlumnos.setItems(getAlumnos());
        colCarne.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("carne"));
        colNombre1.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("nombre1"));
        colNombre2.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("nombre2"));
        colNombre3.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("nombre3"));
        colApellido1.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("apellido1"));
        colApellido2.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("apellido2")); 
    }
    
    private boolean editarStatement(Alumnos alumno){
        CallableStatement sentencia = null;
        alumno = alumnoSelect;
        try {
            String SQL = "CALL sp_alumnos_update(?,?,?,?,?,?);";
            sentencia = Conexion.getInstance().getConnection().prepareCall(SQL);
            
            sentencia.setString(1, alumno.getCarne());
            sentencia.setString(2, alumno.getNombre1());
            sentencia.setString(3, alumno.getNombre2());
            sentencia.setString(4, alumno.getNombre3());
            sentencia.setString(5, alumno.getApellido1());
            sentencia.setString(6, alumno.getApellido2());
            
            System.out.println(sentencia);
            
            sentencia.executeUpdate();
            sentencia.close();
            return true;
        } catch (Exception e) {
            System.err.println("Ocurrio un error al editar el alumno "+e.getMessage());
            System.err.println("Track del error ");
            e.printStackTrace();
            return false;
        }finally{
            try{
                if(sentencia != null){
                    sentencia.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    private void editar() {
        int index = tblAlumnos.getSelectionModel().getSelectedIndex();
        if (index != -1) {
            habilitarCampos();
            alumnoSelect = (Alumnos) tblAlumnos.getItems().get(index);
            if (alumnoSelect != null) {
                lblCarne.setText(alumnoSelect.getCarne());
                txtNombre1.setText(alumnoSelect.getNombre1());
                txtNombre2.setText(alumnoSelect.getNombre2());
                txtNombre3.setText(alumnoSelect.getNombre3());
                txtApellido1.setText(alumnoSelect.getApellido1());
                txtApellido2.setText(alumnoSelect.getApellido2());
            }
        }
    }

    private boolean eliminarStatement(String carne) {
        CallableStatement sentencia = null;
        try {
            String SQL = "CALL sp_alumnos_delete(?);";
            sentencia = Conexion.getInstance().getConnection().prepareCall(SQL);
            sentencia.setString(1, alumnoSelect.getCarne());

            sentencia.executeUpdate();
            sentencia.close();
            return true;
        } catch (Exception e) {
            System.err.println("Ocurrio un error al eliminar la tarea " + e.getMessage());
            System.err.println("Track del error ");
            e.printStackTrace();
            return false;
        }finally{
            try{
                if(sentencia != null){
                    sentencia.close();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    private void eliminar() {
        int index = tblAlumnos.getSelectionModel().getSelectedIndex();
        if (index != -1) {
            alumnoSelect = (Alumnos) tblAlumnos.getItems().get(index);
            System.out.println("\nA eliminar: "+alumnoSelect);

            Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
            confirmacion.setTitle("Confirmacion");
            confirmacion.setHeaderText(null);
            confirmacion.setContentText("Realmente desea eliminar al alumno : " + alumnoSelect.getCarne() + " " + alumnoSelect.getNombre1());
            confirmacion.initStyle(StageStyle.UTILITY);
            Optional<ButtonType> result = confirmacion.showAndWait();

            if (result.get() == ButtonType.OK) {

                boolean rsp = eliminarStatement(alumnoSelect.getCarne());

                if (rsp) {
                    limpiarCampos();
                    deshabilitarCampos();
                    cargarAlumnos();
                    Alert alerta = new Alert(Alert.AlertType.INFORMATION);
                    alerta.setTitle("Exito");
                    alerta.setHeaderText(null);
                    alerta.setContentText("La eliminacion se ha llevado con exito");
                    alerta.initStyle(StageStyle.UTILITY);
                    alumnoSelect = null;
                    alerta.showAndWait();
                } else {
                    Alert alerta = new Alert(Alert.AlertType.ERROR);
                    alerta.setTitle("Error");
                    alerta.setHeaderText(null);
                    alerta.setContentText("Hubo un error, consulte con el programador");
                    alerta.initStyle(StageStyle.UTILITY);
                    alerta.showAndWait();
                }
            }

        }
    }
    
    @FXML
    private void validaciones() {
        //if(rsp == true){
            txtNombre1.setOnMouseClicked(e -> {
               lblAdvertenciaPrimerNombre.setText("CAMPO OBLIGATORIO"); 
  
            });
            
            
            txtApellido1.setOnMouseClicked(e -> {
               lblAdvertenciaPrimerApellido.setText("CAMPO OBLIGATORIO"); 
            });
            
        //}else{
            lblAdvertenciaPrimerNombre.setText("");
            lblAdvertenciaPrimerApellido.setText("");
        }
        
    //}
    
     @FXML
    private void clickObtenerModificar(MouseEvent event) {
        editar();
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarAlumnos();
    }

}
